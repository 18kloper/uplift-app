"use strict";(()=>{var e={};e.id=5614,e.ids=[5614],e.modules={145:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},7174:e=>{e.exports=import("@anthropic-ai/sdk")},151:(e,t,n)=>{n.a(e,async(e,a)=>{try{n.r(t),n.d(t,{config:()=>c,default:()=>u,routeModule:()=>l});var r=n(1802),s=n(7153),o=n(6249),i=n(3670),m=e([i]);i=(m.then?(await m)():m)[0];let u=(0,o.l)(i,"default"),c=(0,o.l)(i,"config"),l=new r.PagesAPIRouteModule({definition:{kind:s.x.PAGES_API,page:"/api/admin/suggest-matches",pathname:"/api/admin/suggest-matches",bundlePath:"",filename:""},userland:i});a()}catch(e){a(e)}})},3670:(e,t,n)=>{n.a(e,async(e,a)=>{try{n.r(t),n.d(t,{default:()=>i});var r=n(7174),s=n(1735),o=e([r]);r=(o.then?(await o)():o)[0];let m=new Set(["kennedy","jackie","aaron","mj"]);async function i(e,t){if("POST"!==e.method)return t.status(405).end();let n=process.env.ADMIN_SECRET;if(n&&e.query.token!==n)return t.status(401).json({error:"Unauthorized"});let{menteeslugs:a=[],mentors:o=[],menteePendingMentors:i={},maxPairings:u}=e.body||{};if(!a.length||!o.length)return t.status(400).json({error:"Need at least one mentee and one mentor"});let c=u||2*o.length,l=a.map(e=>s.Wf.find(t=>t.slug===e)).filter(e=>e&&!m.has(e.slug)).map(e=>({slug:e.slug,name:`${e.first} ${e.last}`,company:e.company||"",industry:e.industry||"",stage:e.stage||"",county:e.county||"",primaryFocus:e.primaryFocus||"",secondaryFoci:(e.secondaryFoci||[]).join(", "),pendingMentor:i[e.slug]||null})),d=process.env.ANTHROPIC_API_KEY;if(!d)return t.status(200).json({error:"No ANTHROPIC_API_KEY"});let g=new r.default({apiKey:d}),p=l.map((e,t)=>`MENTEE ${t+1}: ${e.name} (${e.slug})
  Company: ${e.company} | Industry: ${e.industry} | Stage: ${e.stage}
  Primary focus: ${e.primaryFocus}
  Secondary: ${e.secondaryFoci}${e.pendingMentor?`
  Note: currently assigned to ${e.pendingMentor} (unconfirmed — suggest alternative if stronger fit exists)`:""}`).join("\n\n"),y=o.map((e,t)=>`MENTOR ${t+1}: ${e.name}
  Company: ${e.company||""} | Title: ${e.title||""}
  Industry: ${e.industry||""}
  Focus areas: ${e.focus||""}
  Bio: ${(e.bio||"").slice(0,300)}`).join("\n\n"),h=`You are helping match startup founders with mentors in a NJ-based accelerator program called Uplift.
Each mentor should be matched with exactly 2 mentees where possible (1 is acceptable if no second strong fit exists).
Target: ${c} total pairings across ${o.length} mentors.

CONFIRMED PROGRAM PARTICIPANTS (choose the best 2 per mentor from this pool):
${p}

AVAILABLE MENTORS (each needs 1-2 mentees assigned):
${y}

Return ONLY a JSON array of match objects. Each object must have:
- "mentorName": exact mentor name as listed
- "menteeSlugs": array of 1-2 mentee slugs
- "menteeNames": array of corresponding mentee names
- "reason": 2-3 sentences explaining why this pairing works (specific, reference their industries/focus areas)
- "strength": "strong" | "good" | "fair"

Rules:
- Every mentor must appear exactly once
- Each mentor gets 1-2 mentees; aim for 2 per mentor to reach ${c} total
- A mentee can appear in multiple mentor suggestions (they may benefit from multiple mentors, or you're surfacing alternatives)
- Prioritize: industry alignment → focus area alignment → stage fit → NJ county proximity
- If a mentee already has a pending mentor noted, you may still suggest them to a new mentor if the fit is meaningfully stronger
- Do not invent details not listed above

Return only the JSON array, no other text.`;try{let e=await g.messages.create({model:"claude-opus-4-5",max_tokens:4e3,messages:[{role:"user",content:h}]}),n=(e.content[0]?.text?.trim()||"[]").replace(/^```json\s*/i,"").replace(/^```\s*/i,"").replace(/```\s*$/i,"").trim(),a=JSON.parse(n);return t.status(200).json({matches:a})}catch(e){return console.error("suggest-matches error:",e.message),t.status(500).json({error:e.message})}}a()}catch(e){a(e)}})}};var t=require("../../../webpack-api-runtime.js");t.C(e);var n=e=>t(t.s=e),a=t.X(0,[6707],()=>n(151));module.exports=a})();