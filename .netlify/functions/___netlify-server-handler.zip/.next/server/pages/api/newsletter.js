"use strict";(()=>{var e={};e.id=8527,e.ids=[8527],e.modules={145:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},7174:e=>{e.exports=import("@anthropic-ai/sdk")},6249:(e,t)=>{Object.defineProperty(t,"l",{enumerable:!0,get:function(){return function e(t,n){return n in t?t[n]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,n)):"function"==typeof t&&"default"===n?t:void 0}}})},1609:(e,t,n)=>{n.a(e,async(e,r)=>{try{n.r(t),n.d(t,{config:()=>c,default:()=>l,routeModule:()=>d});var a=n(1802),i=n(7153),s=n(6249),o=n(8716),u=e([o]);o=(u.then?(await u)():u)[0];let l=(0,s.l)(o,"default"),c=(0,s.l)(o,"config"),d=new a.PagesAPIRouteModule({definition:{kind:i.x.PAGES_API,page:"/api/newsletter",pathname:"/api/newsletter",bundlePath:"",filename:""},userland:o});r()}catch(e){r(e)}})},8716:(e,t,n)=>{n.a(e,async(e,r)=>{try{n.r(t),n.d(t,{default:()=>s});var a=n(7174),i=e([a]);async function s(e,t){if("POST"!==e.method)return t.status(405).end();if(!process.env.ANTHROPIC_API_KEY)return t.status(200).json({error:"ANTHROPIC_API_KEY not configured"});let{weekNum:n,promptSections:r,themes:i,sessionIdeas:s,portalStats:o}=e.body||{};try{let e=new a.default({apiKey:process.env.ANTHROPIC_API_KEY}),u=(i||[]).map((e,t)=>`${t+1}. ${e.title}: ${e.description}`).join("\n"),l=(s||[]).map((e,t)=>`${t+1}. ${e.title}: ${e.description}`).join("\n"),c=(r||[]).map(e=>`- ${e.label}: ${e.count} founders (${e.pct}%)`).join("\n"),d=o?`${o.active} active last 5 days, ${o.inactive} not visited in 5 days, ${o.neverVisited} never visited`:"Portal activity data not available",p=await e.messages.create({model:"claude-haiku-4-5",max_tokens:1500,messages:[{role:"user",content:`You are writing the weekly Uplift Summer 2026 newsletter. Uplift is a 9-week startup mentorship accelerator in New Jersey run by TechUnited:NJ. Write a warm, energetic, founder-focused newsletter for Week ${n||"?"}.

Here is the data for this week:

PORTAL ACTIVITY:
${d}

PROMPT COMPLETION RATES:
${c||"No data yet"}

EMERGING THEMES FROM FOUNDER RESPONSES:
${u||"No themes generated yet"}

SESSION IDEAS SURFACING:
${l||"None yet"}

Write a newsletter with:
1. A warm subject line (format: "Uplift Summer 2026 — Week ${n||"?"} Update 🚀")
2. A brief 2-sentence opening that celebrates the cohort's energy
3. "This Week at a Glance" section: bullet list of key stats (portal visits, prompt completions)
4. "What's on Founders' Minds" section: present the top 3-4 themes in plain, human language (not just a list — write it like you're telling a story about what you're observing)
5. "Coming Up" section: 1-2 lines about what's ahead
6. A warm closing sign-off from "The TechUnited:NJ Team"

Keep it under 400 words. Warm but professional. No markdown headers — use plain text with light formatting. Write it ready to copy and send as an email.

Return ONLY a JSON object:
{
  "subject": "the subject line",
  "body": "the full newsletter body as plain text with line breaks"
}`}]}),m=(p.content[0]?.text||"").match(/\{[\s\S]*\}/);if(!m)return t.status(200).json({error:"Could not parse response"});let f=JSON.parse(m[0]);return t.status(200).json({subject:f.subject||"",body:f.body||"",generatedAt:new Date().toISOString()})}catch(e){return console.error("newsletter error:",e.message),t.status(200).json({error:e.message})}}a=(i.then?(await i)():i)[0],r()}catch(e){r(e)}})},7153:(e,t)=>{var n;Object.defineProperty(t,"x",{enumerable:!0,get:function(){return n}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(n||(n={}))},1802:(e,t,n)=>{e.exports=n(145)}};var t=require("../../webpack-api-runtime.js");t.C(e);var n=t(t.s=1609);module.exports=n})();