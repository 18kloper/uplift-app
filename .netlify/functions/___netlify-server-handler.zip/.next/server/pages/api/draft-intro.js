"use strict";(()=>{var e={};e.id=6438,e.ids=[6438],e.modules={145:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},7174:e=>{e.exports=import("@anthropic-ai/sdk")},6249:(e,t)=>{Object.defineProperty(t,"l",{enumerable:!0,get:function(){return function e(t,n){return n in t?t[n]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,n)):"function"==typeof t&&"default"===n?t:void 0}}})},6991:(e,t,n)=>{n.a(e,async(e,r)=>{try{n.r(t),n.d(t,{config:()=>h,default:()=>c,routeModule:()=>d});var o=n(1802),a=n(7153),i=n(6249),s=n(3708),u=e([s]);s=(u.then?(await u)():u)[0];let c=(0,i.l)(s,"default"),h=(0,i.l)(s,"config"),d=new o.PagesAPIRouteModule({definition:{kind:a.x.PAGES_API,page:"/api/draft-intro",pathname:"/api/draft-intro",bundlePath:"",filename:""},userland:s});r()}catch(e){r(e)}})},3708:(e,t,n)=>{n.a(e,async(e,r)=>{try{n.r(t),n.d(t,{default:()=>i});var o=n(7174),a=e([o]);async function i(e,t){if("POST"!==e.method)return t.status(405).end();if(!process.env.ANTHROPIC_API_KEY)return t.status(200).json({error:"ANTHROPIC_API_KEY not configured"});let{founder1:n,founder2:r,sharedTheme:a,reason:i}=e.body||{};if(!n||!r)return t.status(400).json({error:"Missing founders"});let s=n.name.split(" ")[0],u=r.name.split(" ")[0];try{let e=new o.default({apiKey:process.env.ANTHROPIC_API_KEY}),c=await e.messages.create({model:"claude-haiku-4-5",max_tokens:600,messages:[{role:"user",content:`Write a warm, personal intro email connecting two founders in the Uplift Summer 2026 mentorship program at TechUnited:NJ.

FOUNDER 1: ${n.name} (Cohort ${n.cohort} - ${n.cohortName})
FOUNDER 2: ${r.name} (Cohort ${r.cohort} - ${r.cohortName})

SHARED THEME: ${a}
WHY THEY SHOULD CONNECT: ${i}

Follow this structure exactly:

1. Open with: "Hey ${s} and ${u},"

2. One sentence: From the founder insights you've both been sharing, I noticed you two might have a few things in common - thought I'd intro you.

3. One sentence mentioning they're both mentees in the Uplift mentorship program and briefly noting what cohorts they're in.

4. 2-3 sentences: "Here are some of the patterns I noticed:" then describe the specific shared themes and why this pairing makes sense. Draw directly from the reason provided. Be specific, not generic.

5. Closing line: "Feel free to reply all and take it from here - I think you two might be able to exchange some real insights."

6. Sign off:
"Best,
Kennedy"

Keep the whole email under 130 words. Warm, human, direct. No corporate language.

Subject line format (use a regular hyphen, not em dash):
"You two should meet - ${s} ↔ ${u}"

Return ONLY valid JSON:
{
  "subject": "the subject line",
  "body": "the full email body as plain text with line breaks"
}`}]}),h=(c.content[0]?.text||"").match(/\{[\s\S]*\}/);if(!h)return t.status(200).json({error:"Could not parse AI response"});let d=JSON.parse(h[0]);return t.status(200).json({subject:d.subject||"",body:d.body||""})}catch(e){return console.error("draft-intro error:",e.message),t.status(200).json({error:e.message})}}o=(a.then?(await a)():a)[0],r()}catch(e){r(e)}})},7153:(e,t)=>{var n;Object.defineProperty(t,"x",{enumerable:!0,get:function(){return n}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(n||(n={}))},1802:(e,t,n)=>{e.exports=n(145)}};var t=require("../../webpack-api-runtime.js");t.C(e);var n=t(t.s=6991);module.exports=n})();